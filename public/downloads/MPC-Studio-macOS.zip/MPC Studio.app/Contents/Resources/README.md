# MPC Studio

A native Mac companion for the Akai MPC XL. Describe an ambient soundscape, generate bass, chords and melody, preview it on the Mac, then send the notes to the MPC over USB-C. The MPC supplies the sounds. MIDI export keeps the notes editable in your own project. Boom bap, trap, house and metal backing tracks are available too.

The app also provides performance pads, MIDI CC controls, track or sequence selection through Program Change, and MMC transport controls. It is an unofficial companion, not affiliated with Akai, inMusic, Jackson or Fender.

## Browser Studio

Windows and Mac users can open [Browser Studio](https://www.hendrickresearch.com/music/studio/) in current Chrome or Edge on the HTTPS site. It provides a browser CPU music engine, Web MIDI playback and optional model-server connections. Press **Connect** and grant MIDI permission to use a USB MIDI device recognized by your operating system, then prepare a loaded instrument and MIDI routing on the MPC. See the [Browser Studio source and setup](https://github.com/ChaseHendrick/music-field-manual/tree/main/studio).

Akai lists Windows 10 and 11 as supported MPC XL systems. Its FAQ requires the MPC XL driver for USB audio, Controller mode and internal-drive access; it does not establish that every Windows setup exposes standalone USB MIDI without a driver. The browser uses the MIDI endpoint Windows exposes. If that port is missing, check the current MPC XL driver in the inMusic Software Center under **My Hardware → MPC XL** and follow Akai's setup guidance.

Apple Foundation Models is a feature of this native Mac app. Browser Studio has its own controls and validation status. Optional browser model connections require compatible server CORS settings and may request local-network access. Physical playback from Windows to an MPC XL still needs end-to-end validation.

## Requirements

- An Apple Silicon Mac running macOS 26 or later. An M1 Pro is suitable.
- A USB-C cable that carries data, connected to the MPC XL's USB-C computer port.
- For on-device AI: Apple Intelligence enabled in System Settings, in a supported language and region, with its model downloaded and available.
- To build from source: a Swift toolchain with the macOS 26 SDK, such as Xcode 26.

No API key or paid AI service is required for the built-in modes. The app opens with an offline ambient sketch and selects **Apple on-device AI** for new generations when Apple's model is available. Otherwise it selects **Offline music engine**. The composer picker always shows the selected engine.

## Choose a music engine

| Engine | What makes the musical plan | Where it runs |
| --- | --- | --- |
| Apple on-device AI | Apple's Foundation Models language model interprets your description through a constrained arrangement schema | On your Mac; Apple manages its compute |
| Offline music engine | Seeded musical rules use your style and controls, with prompt keywords for space, energy and enabled parts | On your Mac's CPU; no model or network connection required |
| Local / cloud model | A model you configure returns a validated JSON arrangement plan | A local server such as Ollama or LM Studio, or an HTTPS provider you explicitly choose |

All three paths use the same MIDI renderer for harmony, motifs and timing. They design editable note arrangements. They do not generate neural waveform audio, recorded vocals or samples. Every composition identifies its source. The offline engine supports simple directions such as “sparse,” “bright,” “no drums,” and “no melody,” but does not understand every detail of a free-form request. All engines support Ambient, Boom bap, Trap, House and Metal / guitar.

The ambient renderer searches up to 32 open add-nine chord inversions per chord and chooses a complete loop by cyclic dynamic programming. Its cost balances voice movement, large leaps, shared tones, register and the return to the first chord. Held bass and pads move in two-bar sections, while seeded motif rotations, small note changes, and velocity and timing variation develop a sparse melody. Shared sustained pitches are merged to avoid an older note-off cutting off an overlapping pad voice. This is a CPU music algorithm, not a learned audio model.

On-device AI and the offline engine send no musical directions to a server. Apple Intelligence may need an initial system-managed model download. A generation failure preserves the current music and does not silently switch engines.

### Optional local models and cloud providers

Open **Local & optional cloud engines**, configure the connection, then select **Local / cloud model** in the composer picker. The app calls the OpenAI-compatible `chat/completions` endpoint under the base URL you supply. The model and server must support structured JSON responses.

| Connection | Base URL example | Preparation |
| --- | --- | --- |
| Ollama on this Mac | `http://localhost:11434/v1` | Install a model locally and enter its exact model name |
| LM Studio / MLX on this Mac | `http://localhost:1234/v1` | Load a model, start the local server, and enter the served model name |
| Optional cloud provider | `https://your-provider.example/v1` | Supply your provider's compatible HTTPS endpoint, model name and, when required, API key |

The app does not install models or start a model server. GPU offload, MLX execution, context limits and memory use are configured in that server. MIDI scheduling and the musical renderer use the CPU. The displayed Metal device, CPU cores and unified memory describe detected hardware; they are not a benchmark or a claim that a particular model fits in memory. Apple manages the CPU, GPU and other compute used by its own model.

Keep **Use JSON schema constraints** enabled for servers that support `response_format: json_schema`. For a server that supports only JSON mode, disable it to request `json_object`; returned plans are still validated before rendering. The schema asks for four chord-progression scale degrees, an eight-note motif, per-part energies and enabled parts. It constrains musical choices rather than asking a model to return raw MIDI bytes. Unsupported responses, refusals, incomplete output and server errors leave the current composition intact.

Only **Generate**, a requested variation, or **Evolve** sends your musical direction and settings to the custom endpoint. No cloud provider is selected automatically. Use a locally downloaded model for a local workflow; a model server can itself be configured to forward requests to a cloud service. Custom endpoint keys can be stored in the Mac Keychain with **Save connection** and removed with **Forget saved key**. Keys are excluded from session JSON. Remote connections require HTTPS; plain HTTP is accepted only for loopback hosts on your Mac, and redirects are rejected.

## First USB-C session

1. Turn on the MPC XL, connect its USB-C computer port directly to your Mac, and keep the MPC in **Standalone mode**.
2. On the MPC, open **Menu → Preferences → MIDI/Sync**. Find **USB MIDI Port 1** in Input Ports, enable **Track**, and disable **Global** for independent instrument routing. Global sends incoming MIDI to the currently selected track.
3. Load one plugin or keygroup instrument on the MPC. Set its MIDI Input to **USB MIDI Port 1**, channel **1**. Choose **In** monitoring to hear incoming notes, or **Merge** to hear incoming notes together with events already in the MPC sequence. A drum pad can be played with the performance pads, but a pitched instrument is the useful starting point for ambient chords and melody.
4. MPC Studio looks for MPC MIDI destinations automatically. If there is no unique match, select the destination yourself in the connection controls. Akai describes Mac ports such as **MPC MIDI 1 & 2**; choose the one corresponding to Port 1. The name shown by CoreMIDI may differ.
5. The app opens with an offline ambient sketch at 64 BPM in D minor, eight bars long, with drums muted. Bass, chords and melody all use channel 1, so one prepared MPC instrument is enough to begin. Preview it on the Mac, then play it through the selected MPC destination. Check the composer picker before generating a new version.

For independent instrument sounds, turn off **Simple ambient setup: layer bass, pads and melody on channel 1** and prepare the following MPC tracks:

| Part | App's default MIDI channel | Prepare on the MPC |
| --- | --- | --- |
| Drums | 1 | Drum track with a loaded kit |
| Bass | 2 | Plugin or keygroup track with a bass sound |
| Chords | 3 | Plugin or keygroup track with a chord sound |
| Melody | 4 | Plugin or keygroup track with a lead sound |

Channels are adjustable in the app. On the MPC, use specific channels rather than **All** for this four-part setup. Ambient starts with drums muted; enable that part when you want percussion. A MIDI-only track that sends to external gear does not produce an internal MPC sound by itself.

If no device appears, confirm the cable carries data and check Akai's current MPC XL driver in the inMusic Software Center. Akai requires that driver for USB audio, Controller mode and access to the MPC's internal drive. MPC Studio uses the MIDI endpoints macOS exposes and does not install drivers.

### Drum mapping and Mac preview

The app starts with General MIDI drum notes: kick 36, snare 38, closed hat 42, open hat 46 and crash 49. These numbers do not guarantee that a particular MPC kit places those sounds on those notes. Use the app's drum mapping controls, or the MPC drum track's **Edit Pad Note Map**, to match your loaded kit. Save a session to keep your mapping.

Mac preview uses the Mac's General MIDI sound bank, with drums on channel 10. It is an arrangement preview. It does not audition the actual MPC kit, plugins or effects. Playback to the MPC and exported MIDI use your configured MPC channels and drum mapping instead.

Ambient Mac preview selects General MIDI warm-pad, bass and celesta sounds. Those preview-only Program Change messages are excluded from normal MIDI export and live MPC playback, so those paths use the instruments you prepare.

## Compose, perform and keep the music

- Choose a style, describe the groove, and set tempo, key, scale, bars, density and swing. Generate again or request a variation to explore another take.
- Try the **Coast at dusk**, **Rain through glass**, **Slow orbit**, and **Forest after rain** scenes as ambient starting points.
- Mute individual parts and loop the composition while playing guitar or trying MPC sounds.
- With **Loop MPC** and **Evolve** enabled, the app prepares a variation every four loops using the selected composer, then queues the result for the next loop boundary. Evolution keeps using the selected engine and configured model. It does not quietly switch engines when generation fails.
- Use the performance pads to send notes at the chosen base note, channel and velocity.
- Map the app's CC controls with MPC MIDI Learn for effects, instrument parameters or mixer controls. Enable **Control** for the USB input port in MPC MIDI/Sync, enter MIDI Learn, select the target, and move an app control. Save the MPC project to preserve its mapping.
- Export a `.mid` file, then load it through the MPC Browser. MIDI contains note and timing data, not your instrument audio. Live playback alone does not save a sequence on the MPC.
- Save or open an app session as JSON to keep the prompt, settings, composition, channels, drum mappings and muted parts. This session is separate from an MPC project.

### Transport, Program Change and clock

For transport control, enable **Receive MMC** in the MPC's MIDI/Sync preferences. The app sends standard MIDI Machine Control. Akai documents Deferred Play, Stop, Record Strobe, Pause and Locate support. MPC transport cannot be assigned through MIDI Learn. The MPC must already have the intended project, tracks and recording setup prepared.

MPC 3's **Program Change** setting chooses whether received messages select a **Track** or a **Sequence**. Choose the intended behavior on the MPC before using the app's selector. Item 1 corresponds to MIDI Program Change 0. This is not a plugin preset browser.

Clock transmission is optional and starts off. For Mac-master MIDI sync, turn it on in the app and set the MPC's **Sync Receive** to **MIDI Clock**. For ordinary live note playback, leave Sync Receive **Off** and keep the app and MPC tempos aligned manually when needed.

**Audio recording limitation:** the official MPC Live III / XL v3.7 manual states that audio recording is disabled while receiving MIDI Clock. It recommends MIDI Time Code for audio recording while receiving sync. MPC Studio does not send MTC. Leave external clock off when recording your Jackson or sampling audio on the MPC unless you have another suitable sync workflow.

The app's stop/panic controls release notes and send MIDI cleanup. On the MPC, leave **Filter 'All Notes Off' CC** disabled if you want it to accept panic CC messages.

## Scope and validation

The app works through documented MIDI messages. It does not read the MPC's loaded sounds or project state, remotely load samples, navigate every hardware screen, or replace MPC desktop software. Its current audio workflow is Mac preview plus MIDI playback/export; it does not record USB audio or generate sample packs.

The USB-C workflow and supported message types are based on Akai documentation. End-to-end playback, MMC and recording on a connected MPC XL still require hardware validation. A successful MIDI send means CoreMIDI accepted the message for that destination; it does not confirm that the MPC played or saved it.

Apple Foundation Models inference was tested on the development Mac with the final ambient renderer using `--ai-check`. It produced “Dusk Coastline Ambient Loop,” a validated D minor arrangement with 18 MIDI notes. This verifies on-device generation and MIDI rendering for that request. No MPC endpoint was connected during that check. The 16 Swift Testing checks also passed.

JSON-plan and integration protocol tests are separate from real provider validation. Ollama, LM Studio, MLX and custom cloud connections still have fixture coverage only and need end-to-end testing with an installed or configured model. Structured-output support varies by server and model. No generation speed, audio quality or model ranking has been benchmarked.

Controller mode is a separate Akai workflow. It requires the MPC XL driver, compatible MPC desktop software and firmware, and the desktop application running. Keep the unit in Standalone mode for this companion's intended workflow.

## Build and package

From `native/MPCStudio`, build or run the test suite:

```sh
swift build --configuration release --scratch-path /absolute/path/to/work/mpc-studio-build
swift test --disable-xctest --scratch-path /absolute/path/to/work/mpc-studio-build
```

The suite uses Swift Testing. It checks voice movement against naive chord voicings, seeded determinism and variety, all styles and scales, sustained notes without same-pitch overlaps, malformed settings and MIDI export with an independent parser.

If the Command Line Tools Swift 6.4 preview compiler reports a missing `TestingMacros` plugin, the development check succeeded by explicitly loading the installed plugin. This workaround is specific to that toolchain; a standard Xcode 26 toolchain should use the normal command above:

```sh
swift test --disable-xctest --scratch-path /private/tmp/mpc-studio-tests \
  -Xswiftc -load-plugin-library \
  -Xswiftc /Library/Developer/CommandLineTools/usr/lib/swift/host/plugins/testing/libTestingMacros.dylib
```

Package an Apple Silicon app bundle and ZIP:

```sh
bash scripts/package-app.sh /absolute/path/to/output /absolute/path/to/work/mpc-studio-build
```

The first argument is the required absolute output directory. The optional second argument is the build scratch directory; it defaults to this package's `.build`. The script produces **MPC Studio.app** and **MPC-Studio-macOS.zip**, includes the setup notes and license, and applies a local ad hoc signature. It does not notarize or launch the app. An optional icon is read from `Resources/AppIcon.icns`.

For a downloaded build, macOS may block the first launch because it is not Developer ID signed or notarized. After attempting to open it, review the app in **System Settings → Privacy & Security** and choose **Open Anyway** if you wish to trust that build. See [Apple's first-launch guidance](https://support.apple.com/en-us/102445).

Inspect MIDI endpoints and model availability without opening a window:

```sh
"/absolute/path/to/output/MPC Studio.app/Contents/MacOS/MPCStudio" --diagnostics
```

Exercise Apple's real on-device inference and validate the resulting arrangement without opening a window:

```sh
"/absolute/path/to/output/MPC Studio.app/Contents/MacOS/MPCStudio" --ai-check
```

## Primary documentation

- [Akai MPC XL FAQ](https://support.akaipro.com/en/support/solutions/articles/69000875625-mpc-xl-frequently-asked-questions): USB-C MIDI/audio, driver requirements and supported modes.
- [Akai direct USB MIDI setup](https://support.akaipro.com/en/support/solutions/articles/69000876025-akai-mpc-series-how-to-use-3rd-party-vst-s-with-your-mpc): standalone USB-C connectivity.
- [Akai MIDI routing and monitoring](https://support.akaipro.com/en/support/solutions/articles/69000804431-akai-pro-mpc-x-mpc-live-mpc-one-configuring-midi-ports-for-multi-midi-control): Global, Control, Track and input monitoring.
- [Akai MIDI Learn](https://support.akaipro.com/en/support/solutions/articles/69000858700-akai-pro-mpc-%E3%82%B7%E3%83%AA%E3%83%BC%E3%82%BA-midi-learn-%E3%81%AB%E3%82%88%E3%82%8B%E3%83%97%E3%83%A9%E3%82%B0%E3%82%A4%E3%83%B3%E3%83%BB%E3%82%A4%E3%83%B3%E3%82%B9%E3%83%88%E3%82%A5%E3%83%AB%E3%83%A1%E3%83%B3%E3%83%88%E3%81%A8-fx-%E3%83%91%E3%83%A9%E3%83%A1%E3%83%BC%E3%82%BF%E3%83%BC%E3%81%AE%E3%83%9E%E3%83%83%E3%83%94%E3%83%B3%E3%82%B0): parameter mapping and MMC transport distinction.
- [Akai Program Change setup](https://support.akaipro.com/en/support/solutions/articles/69000858922-akai-pro-mpc-series-how-to-set-up-the-mpc-to-receive-program-changes): Track/Sequence selection and numbering.
- [Official MPC Live III / XL user guide v3.7](https://cdn.inmusicbrands.com/Software/37/MPC%20Live%20III%2C%20MPC%20XL%20-%20User%20Guide%20-%20v3.7.pdf): pages 62–63 for MIDI/Sync and the audio recording limitation; page 126 for drum note maps; page 523 for MMC.
- [Apple Foundation Models](https://developer.apple.com/documentation/FoundationModels/generating-content-and-performing-tasks-with-foundation-models): on-device sessions and availability checks.
- [Apple SystemLanguageModel](https://developer.apple.com/documentation/foundationmodels/systemlanguagemodel): supported availability conditions.
- [Apple CoreMIDI](https://developer.apple.com/documentation/coremidi/midi-services): MIDI endpoint and message transport APIs.
- [Ollama OpenAI compatibility](https://docs.ollama.com/api/openai-compatibility): local server base URL and chat-completions support.
- [LM Studio structured output](https://lmstudio.ai/docs/developer/openai-compat/structured-output): JSON schema responses and model support requirements.
- [LM Studio app documentation](https://lmstudio.ai/docs/app): local models and Apple Silicon MLX support.
- [Web MIDI API](https://developer.mozilla.org/en-US/docs/Web/API/Web_MIDI_API): secure context, device access and explicit browser permission.
- [Chrome Local Network Access](https://developer.chrome.com/blog/local-network-access): permissions for connections from a public site to a local model server.

## License

MPC Studio inherits this repository's [PolyForm Small Business License 1.0.0](../../LICENSE). See the repository license for its terms and required notice.
